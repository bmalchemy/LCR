import React from 'react';
import Prayershawl from './PrayerShawl';
import Community from './Community';

export default function Connect() {
    return (
        <div class="lowerTop"> 
            <Community />
            <Prayershawl />
        </div>
    )
}