import React from 'react';
const pastor = require('../media/images/pastor.jpg');

var style0 = {

}

export default function Pastor() {
    return (
        <div>
            Pastor: Rebecca Sogge
            <img src={pastor} style={style0} alt="pastor" />
        </div>
    )
}