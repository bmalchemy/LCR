import React from 'react';
import { Link } from 'react-router-dom'

var style1 = {
    textAlign: "center"
}
export default function TeamMembers() {

    return (
        <div>
            <section id="ministryteam" class="row text-banner">

                <div class="middleBodySubText">

                    <div style={style1}><div class="joiningheading">Team Members</div></div>
                    <Link to='/about/pastor'>Pastor: Rebecca Sogge</Link>
                </div>
            </section>
        </div>
    )
}